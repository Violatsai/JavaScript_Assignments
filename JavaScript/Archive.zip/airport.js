function lookup(destination, travelDay){
    if (destination == "Tokyo" && travelDay == 2){
        return "MAS 304©Tuesday©15:30©6:30©$650.00";
    }else if (destination == "London" && travelDay == 2){
        return "MAS 975©Tuesday©20:00©14:00©$500.00";
    }else if (destination == "London" && travelDay == 3){
        return "MAS 888©Tuesday©20:00©14:00©$888.00";
        }
}